==================
 LibradosPP (C++)
==================

.. todo:: write me!
